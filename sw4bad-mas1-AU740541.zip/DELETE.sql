USE experienceSharedDb;


DROP TABLE SEGuests;
DROP TABLE SEDets;
DROP TABLE SE;
DROP TABLE Experiences;
DROP TABLE Guests;
DROP TABLE Providers;